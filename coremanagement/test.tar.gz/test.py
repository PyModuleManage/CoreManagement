#!/bin/usr/python3

def main():
    print('Hola mundo!!!')


if __name__ == '__main__':
    main()
